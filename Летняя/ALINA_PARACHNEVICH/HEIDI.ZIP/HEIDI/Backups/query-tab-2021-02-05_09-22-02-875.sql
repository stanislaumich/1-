CREATE TABLE `postav` (
	`idpostav` INT NOT NULL AUTO_INCREMENT,
	`fio` VARCHAR(500) NULL DEFAULT NULL,
	`uradr` VARCHAR(500) NULL DEFAULT NULL,
	`idschet` INT NULL,
	PRIMARY KEY (`idpostav`),
	UNIQUE INDEX `idpostav` (`idpostav`)
)
COMMENT='Поставщики'
COLLATE='utf8mb4_0900_ai_ci'
;
